import { config } from 'dotenv';
config();

import '@/ai/flows/generate-alt-text.ts';
import '@/ai/flows/send-lead.ts';
import '@/ai/flows/listFiles.ts';
